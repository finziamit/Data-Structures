public class ListTestObject extends ListTest<Object>{

	@Override
	public Object getParameterInstance() {
		return new Object();
	}
}
